A.S.T.R.O AI Clean 1.9.3 - CLEAN (no API keys)
Platform: linux x86_64

This build contains NO API keys. It starts fresh with the keyless free providers;
add your own keys in Settings > Keys. Safe to share.
Data folder: Windows %APPDATA%\Astro AI Clean | Linux ~/.local/share/astro-ai-clean | macOS ~/Library/Application Support/Astro AI Clean

Install: sudo apt install ./<file>.deb    (or: tar xf <file>.tar.gz && ./astro-ai*/install.sh)
Needs WebKitGTK 4.1 (libwebkit2gtk-4.1-0), libcurl and OpenSSL 3 (glibc 2.35+: Ubuntu 22.04+, Debian 12+, Fedora 36+).

The app runs a local server on 127.0.0.1 only; AI calls go straight from your computer to the providers.

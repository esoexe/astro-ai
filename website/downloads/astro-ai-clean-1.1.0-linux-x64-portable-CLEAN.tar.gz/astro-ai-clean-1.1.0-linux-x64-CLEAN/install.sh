#!/usr/bin/env bash
# Adds Astro AI Clean to your app menu (no root needed). Run it from where you keep this folder.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
mkdir -p ~/.local/share/applications ~/.local/share/icons/hicolor/256x256/apps
cp "$D/icon.png" ~/.local/share/icons/hicolor/256x256/apps/astro-ai-clean.png
sed -e "s|^Exec=.*|Exec=\"$D/astro-desktop\"|" > ~/.local/share/applications/astro-ai-clean.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=Astro AI Clean
GenericName=AI workspace
Comment=Chat, code Workspace and Agent powered by one brain of free AI models
Exec=/usr/bin/astro-ai-clean
Icon=astro-ai-clean
Terminal=false
Categories=Development;Utility;
Keywords=AI;chat;assistant;code;agent;
StartupWMClass=astro-ai-clean
DESK
update-desktop-database ~/.local/share/applications 2>/dev/null || true
echo "Astro AI Clean added to your applications menu. You can also run: $D/astro-desktop"

Astro AI Clean 1.4.0 - CLEAN (no API keys)
Platform: windows x64

This build contains NO API keys. It starts fresh with the keyless free providers;
add your own keys in Settings > Keys. Safe to share.
Data folder: Windows %APPDATA%\Astro AI Clean | Linux ~/.local/share/astro-ai-clean | macOS ~/Library/Application Support/Astro AI Clean

Install: run the Setup .exe (no admin needed), or unzip the portable folder and run the .exe.
Needs the Microsoft Edge WebView2 Runtime (built into Windows 11 / updated Windows 10; the installer adds it if missing).
To run code and terminal commands in the Workspace/Agent, install Git for Windows (bash): https://git-scm.com/download/win

The app runs a local server on 127.0.0.1 only; AI calls go straight from your computer to the providers.

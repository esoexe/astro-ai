A.S.T.R.O AI Clean 1.4.1 - CLEAN (no API keys)
Platform: macos (build on a Mac)

This build contains NO API keys. It starts fresh with the keyless free providers;
add your own keys in Settings > Keys. Safe to share.
Data folder: Windows %APPDATA%\Astro AI Clean | Linux ~/.local/share/astro-ai-clean | macOS ~/Library/Application Support/Astro AI Clean

Build on your Mac: install the Xcode Command Line Tools (xcode-select --install), then run ./build_mac.sh
It produces the .app and a .dmg (universal: Apple Silicon + Intel).

The app runs a local server on 127.0.0.1 only; AI calls go straight from your computer to the providers.

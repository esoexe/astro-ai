A.S.T.R.O AI PRESS KIT  (version 1.5.0, October 29, 2026)

Name:     A.S.T.R.O AI  (written with the dots; say it as one word, "Astro AI")
Stands for: All Systems Thinking, Reasoning as One
Tagline:  One brain, many minds.
New in 1.5: a full-screen terminal app (astro), a redesigned desktop Agent page with a
          Session panel, and a new icon (screenshots named v1.5-*).

Boilerplate
A.S.T.R.O AI is a free AI workspace for Windows, Linux and macOS where a team of free AI
models works as one. Its One Brain mode sends a question to many models, has them review
each other's drafts and merges the result into one answer. A coding agent plans, writes and
tests code in your own folders, from the desktop app, the astro terminal app or VS Code,
with Plan, Ask and Auto permission modes and a checkpoint to undo every change.
A.S.T.R.O AI needs no account and has no telemetry. Data is stored on the user's computer.

Facts
- Platforms: Windows 10/11 x64, Linux x64 (glibc 2.35+), macOS 11+
- Price: free. Models come from providers' free tiers, which have usage limits.
- Providers: 62 free (4 work with no key, 47 with the user's own free key, 11 local);
  30 paid providers are opt-in and off by default.
- Terminal-only install:
    curl -fsSL https://esoexe.github.io/astro-ai/install.sh | sh
    irm https://esoexe.github.io/astro-ai/install.ps1 | iex
- Website: https://esoexe.github.io/astro-ai/
- Source: https://github.com/esoexe/astro-ai (MIT OR Apache-2.0 OR GPL-3.0)

Colours
  Space          #0A0A0C
  Starlight      #F4F4F5
  Orbit peach    #F3A679
  Core gradient  #FFD2B0 -> #F08A4B
  Moon           #FAB283

Typography (all SIL Open Font License)
  Instrument Serif  headlines (italic in orbit peach for emphasis)
  Inter             interface and body
  JetBrains Mono    labels and code

Icon
A peach sphere inside three crossed orbits with four satellites, on a dark squircle.
Please don't recolour, stretch, rotate or add effects to the icon.
Keep clear space of at least 25% of its width around it.

Trailer
https://esoexe.github.io/astro-ai/assets/video/astro-ai-trailer.mp4 (90 s, 1920x1080)
Real footage of the app and the astro command. Narration is a synthesized voice.
Music: "Clean Soul" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

Contents
  icons/        app icon PNGs, 32 to 1024 px (+ macOS-style 1024)
  screenshots/  v1.5-*: real screenshots of A.S.T.R.O AI 1.5.0 (desktop 1728x1080,
                terminal 2464x1386); v1.1-*: version 1.1; the rest: version 1.0
                and the Windows installer (860x560)
  astro-ai-social-card-1200x630.png

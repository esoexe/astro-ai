ASTRO AI PRESS KIT  (version 1.0.0, October 27, 2026)

Name:     Astro AI
Tagline:  One brain, many minds.

Boilerplate
Astro AI is a free desktop app for Windows, Linux and macOS where a team of free AI models
answers as one. Its One Brain mode sends each question to every available model, has them
review each other's drafts, and merges the result into a single answer. It also includes a
code Workspace, an autonomous Agent, live voice, Model Lab, Reader, notes and tasks.
Astro AI needs no account and has no telemetry. Data is stored on the user's computer.

Facts
- Platforms: Windows 10/11 x64, Linux x64 (glibc 2.35+), macOS 11+ (build kit, universal)
- Price: free. Models come from providers' free tiers, which have usage limits.
- Models: 26 out of the box; 50+ providers supported with the user's own free keys.
- A full One Brain answer usually takes a few minutes; single models answer quickly.

Colours
  Space          #0A0A0C
  Starlight      #F4F4F5
  Orbit peach    #F3A679
  Core gradient  #FFD2B0 -> #F08A4B
  Moon           #FAB283

Typography (all SIL Open Font License)
  Instrument Serif  headlines (italic in orbit peach for emphasis)
  Inter             interface and body
  JetBrains Mono    labels and code

Icon use
Please don't recolour, stretch, rotate or add effects to the icon.
Keep clear space of at least 25% of its width around it.

Contents
  icons/        app icon PNGs, 32 to 1024 px (+ macOS-style 1024)
  screenshots/  real screenshots of Astro AI 1.0.0 (1440x900) and the Windows installer (860x560)
  astro-ai-social-card-1200x630.png
